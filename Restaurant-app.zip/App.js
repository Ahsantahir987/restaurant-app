import ScreenNavigation from "./navigation/screen_navigation";

export default function App() {
  return <ScreenNavigation></ScreenNavigation>;
}
